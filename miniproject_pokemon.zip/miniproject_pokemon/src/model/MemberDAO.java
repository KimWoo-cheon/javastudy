package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class MemberDAO {// DAO(Data Access Object) : DBMS에 접근하는 객체
	PreparedStatement psmt = null;
	Connection conn = null;
	ResultSet rs = null;
	int row = 0;

	// DB접속 메소드
	public void getConn() {
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");

//				String url = "jdbc:oracle:thin:@localhost:1521:xe";
				String url = "jdbc:oracle:thin:@project-db-campus.smhrd.com:1523:xe";
				String user = "mp_24K_DCXBIG_p1_1";
				String db_pw = "smhrd1";

				conn = DriverManager.getConnection(url, user, db_pw);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	// DB종료 메소드
	public void getClose() {

		try {
			// 문닫기 : 무조건 실행, 역순으로 닫기
			if (rs != null)
				rs.close();
			if (psmt != null)
				psmt.close();
			if (conn != null)
				conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// 회원가입 기능
	public int register(Member player) {

		try {

			getConn();

			String sql = "insert into mem values(?, ?, ?)";

			psmt = conn.prepareStatement(sql);

			psmt.setString(1, player.getId());
			psmt.setString(2, player.getPw());
			psmt.setString(3, player.getName());
	

			// 8.실행
			row = psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}
		return row;

	}

	// 로그인 기능
	public String login(Member player) {

		String name = null;
		try {

			getConn();

			String sql = "select name from mem where id = ? and pw = ?";

			psmt = conn.prepareStatement(sql);

			psmt.setString(1, player.getId());
			psmt.setString(2, player.getPw());

			rs = psmt.executeQuery();

			if (rs.next()) {
				// 값을 가져오기
				name = rs.getString("name");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			getClose();

		}
		return name;

	}

	// 회원정보수정
	public int update(Member player, Member playerNew) {
		try {
			getConn();

			String sql = "update MEMBER set ID= ?, PW= ? , NAME=? where ID=? and PW=?";

			psmt = conn.prepareStatement(sql);

			psmt.setString(1, playerNew.getId());
			psmt.setString(2, playerNew.getPw());
			psmt.setString(3, playerNew.getName());
			psmt.setString(4, player.getId());
			psmt.setString(5, player.getPw());

			row = psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			getClose();
		}

		return row;

	}

	// 회원정보 삭제
	public int delete(Member player) {
		try {
			getConn();
			String sql = "delete from MEMBER where ID=? and PW=?";

			psmt = conn.prepareStatement(sql);

			psmt.setString(1, player.getId());
			psmt.setString(2, player.getPw());

			row = psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			getClose();
		}
		return row;
	}

	// 회원정보조회
	public ArrayList<Member> join() {
		ArrayList<Member> memList = new ArrayList<Member>();
		try {
			getConn();
			String sq1 = "select * from member";
			psmt = conn.prepareStatement(sq1);

			rs = psmt.executeQuery();
//			 rs.next()반복필요 -> 반복 횟수가 정해져 있지 않음
			while (rs.next()) {

				String id = rs.getString(1);
				String pw = rs.getString(2);
				String name = rs.getString(3);

				Member player= new Member(id, pw, name);
				memList.add(player);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			getClose();
		}
		return memList;
	}
}
