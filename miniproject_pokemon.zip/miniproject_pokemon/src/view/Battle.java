package view;

public class Battle {

	public static void main(String[] args) {
		System.out.println(PMDAO.);

	}

}
