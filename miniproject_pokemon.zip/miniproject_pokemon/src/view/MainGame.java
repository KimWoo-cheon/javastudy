package view;

import java.util.Scanner;

import controller.Controller;
import model.PM;
import model.PMDAO;

public class MainGame {

	public static void main(String[] args) {
		
		PMDAO pmdao = new PMDAO();
		Controller con = new Controller();

		Scanner sc = new Scanner(System.in);
		System.out.println("================= 게임을 시작하시겠습니까 ?=============");

		System.out.println("==============[1]예 [2]아니오 ============= ");
		int menu = sc.nextInt();
		if (menu == 1) {

			System.out.println("포켓몬 타입을 선택하세요.");
			for (int j = 0; j < j + 1; j++) {
				System.out.println("==============[1]불꽃 [2]물 [3]풀 [4]전기 [5]땅 ============= ");
				int typenum = sc.nextInt();
				System.out.println("******** 주의 포켓몬별 공격력은 비공개 ********");				
				con.pmjoin(typenum);
				String choice=sc.next();
				
				System.out.println(pmdao.Choice(choice).toString()); 
			
				System.out.println("");
				
				
//				String mypm = sc.next();
//				if(mypm.equls())
			}
		}

		if (menu == 2) {
			Main.main(args);
		}

//			System.out.println("포켓몬을 " + "선택하세요.");
//
//			System.out.println("사천왕오창민을 마주쳤다.");
//			System.out.println("~을 마주쳤다.");
//			System.out.println("~을 마주쳤다.");
//			System.out.println("~을 마주쳤다.");
//			System.out.println("~을 마주쳤다.");
//
//			///////////////// 배틀
//			System.out.println("공격" + "도망가기");
//			System.out.println("~로부터 도망쳤다.");
//			System.out.println("~가 쓰러졌다.");
//			System.out.println("효과가 굉장했다.");
//			System.out.println("you lose ");
//			System.out.println("다음 스테이지");
//			System.out.println("최종 스테이지");
//			System.out.println("승리" + "패배");
//			System.out.println("포켓몬마스터가 되었습니다.");

	}

}
